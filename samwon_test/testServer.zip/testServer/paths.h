#pragma once

#define CAMERA_IMAGE_PATH "imageBuff/cameraShoot.jpg"